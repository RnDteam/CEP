package tester;

import java.time.ZonedDateTime;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import train.Coach;
import train.ConceptFactory;
import train.Train;
import train.TrainInit;

import com.ibm.ia.common.GatewayException;
import com.ibm.ia.common.RoutingException;
import com.ibm.ia.common.SolutionException;
import com.ibm.ia.testdriver.TestDriver;

public class Tester {

	protected static TestDriver testDriver;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		testDriver = new TestDriver();
		testDriver.connect();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		testDriver.disconnect();
		testDriver = null;
	}

	@Before
	public void setUp() throws Exception {
		testDriver.deleteAllEntities();
		testDriver.resetSolutionState();
		testDriver.startRecording();
	}

	@After
	public void tearDown() throws Exception {
        testDriver.endTest();
		testDriver.stopRecording();
	}

	@Test
	public void test1() throws SolutionException, GatewayException,
			RoutingException, InterruptedException {

		
		ConceptFactory factory = testDriver.getConceptFactory(ConceptFactory.class);
		Coach coach = factory.createCoach("1", 10, 2);
		ZonedDateTime now = ZonedDateTime.now();
		TrainInit trainInit = factory.createTrainInit(coach, "1", now);
		
		testDriver.submitEvent(trainInit);
		
		Thread.sleep(1000);
		
		Train train = testDriver.fetchEntity(Train.class, "1");
		assert train != null;
		
	}
	
}