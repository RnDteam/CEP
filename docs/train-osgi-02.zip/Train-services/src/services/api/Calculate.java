package services.api;

import train.Coach;

public interface Calculate {
	public double count(Coach coach);
}
