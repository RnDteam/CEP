package services.impl;

import services.api.Calculate;
import train.Coach;

public class CalculateImpl implements Calculate {
	@Override
	public double count (Coach coach) {
		return coach.getLaneNumber() * coach.getRowNumber();
	}
}
